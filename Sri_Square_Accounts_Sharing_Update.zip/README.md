# Sri Square Accounts

Updated version with Share Report using the iPhone share sheet (including WhatsApp), plus Print / Save PDF.

Data remains local on the device until cloud sync is added.
